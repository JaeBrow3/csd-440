<?php
/*
    File Name: JamesMyInteger.php
*/

/**
 * Class JamesMyInteger
 *
 * Stores a single integer and provides methods
 * to test whether a number is even, odd, or prime.
 */
class JamesMyInteger
{
    /**
     * @var int Stores the integer value
     */
    private $number;

    /**
     * Constructor method
     *
     * @param int $number The integer value to store
     */
    public function __construct($number)
    {
        $this->number = $number;
    }

    /**
     * Getter method for the stored number
     *
     * @return int The current stored integer
     */
    public function getNumber()
    {
        return $this->number;
    }

    /**
     * Setter method for the stored number
     *
     * @param int $number The new integer value
     * @return void
     */
    public function setNumber($number)
    {
        $this->number = $number;
    }

    /**
     * Checks whether a number is even
     *
     * @param int $value The number to test
     * @return bool True if even, false otherwise
     */
    public function isEven($value)
    {
        return $value % 2 == 0;
    }

    /**
     * Checks whether a number is odd
     *
     * @param int $value The number to test
     * @return bool True if odd, false otherwise
     */
    public function isOdd($value)
    {
        return $value % 2 != 0;
    }

    /**
     * Checks whether the stored number is prime
     *
     * @return bool True if prime, false otherwise
     */
    public function isPrime()
    {
        if ($this->number < 2) {
            return false;
        }

        for ($i = 2; $i <= sqrt($this->number); $i++) {
            if ($this->number % $i == 0) {
                return false;
            }
        }

        return true;
    }
}

/*
    Create two instances of the JamesMyInteger class
    and test all methods.
*/
$number1 = new JamesMyInteger(7);
$number2 = new JamesMyInteger(10);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>James MyInteger</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 30px;
            text-align: center;
        }

        table {
            margin: 20px auto;
            border-collapse: collapse;
            width: 70%;
        }

        th, td {
            border: 1px solid black;
            padding: 10px;
            text-align: center;
        }

        th {
            background-color: #f2f2f2;
        }

        h1, h2 {
            margin-top: 20px;
        }
    </style>
</head>
<body>

    <h1>JamesMyInteger Class Program</h1>
    
    <table>
        <tr>
            <th>Test</th>
            <th>First Object</th>
            <th>Second Object</th>
        </tr>
        <tr>
            <td>Original Number</td>
            <td><?php echo $number1->getNumber(); ?></td>
            <td><?php echo $number2->getNumber(); ?></td>
        </tr>
        <tr>
            <td>Is Even?</td>
            <td><?php echo $number1->isEven($number1->getNumber()) ? "Yes" : "No"; ?></td>
            <td><?php echo $number2->isEven($number2->getNumber()) ? "Yes" : "No"; ?></td>
        </tr>
        <tr>
            <td>Is Odd?</td>
            <td><?php echo $number1->isOdd($number1->getNumber()) ? "Yes" : "No"; ?></td>
            <td><?php echo $number2->isOdd($number2->getNumber()) ? "Yes" : "No"; ?></td>
        </tr>
        <tr>
            <td>Is Prime?</td>
            <td><?php echo $number1->isPrime() ? "Yes" : "No"; ?></td>
            <td><?php echo $number2->isPrime() ? "Yes" : "No"; ?></td>
        </tr>
    </table>

    <h2>Testing the Setter Method</h2>
    <?php
    // Change the stored numbers using the setter method
    $number1->setNumber(12);
    $number2->setNumber(13);
    ?>

    <table>
        <tr>
            <th>Test After Setter</th>
            <th>First Object</th>
            <th>Second Object</th>
        </tr>
        <tr>
            <td>Updated Number</td>
            <td><?php echo $number1->getNumber(); ?></td>
            <td><?php echo $number2->getNumber(); ?></td>
        </tr>
        <tr>
            <td>Is Even?</td>
            <td><?php echo $number1->isEven($number1->getNumber()) ? "Yes" : "No"; ?></td>
            <td><?php echo $number2->isEven($number2->getNumber()) ? "Yes" : "No"; ?></td>
        </tr>
        <tr>
            <td>Is Odd?</td>
            <td><?php echo $number1->isOdd($number1->getNumber()) ? "Yes" : "No"; ?></td>
            <td><?php echo $number2->isOdd($number2->getNumber()) ? "Yes" : "No"; ?></td>
        </tr>
        <tr>
            <td>Is Prime?</td>
            <td><?php echo $number1->isPrime() ? "Yes" : "No"; ?></td>
            <td><?php echo $number2->isPrime() ? "Yes" : "No"; ?></td>
        </tr>
    </table>

</body>
</html>