<?php
/*
    File Name: JamesResponse.php
*/

$errors = array();

$firstName = trim($_POST["firstName"] ?? "");
$lastName = trim($_POST["lastName"] ?? "");
$age = trim($_POST["age"] ?? "");
$email = trim($_POST["email"] ?? "");
$phone = trim($_POST["phone"] ?? "");
$dob = trim($_POST["dob"] ?? "");
$favoriteColor = trim($_POST["favoriteColor"] ?? "");

/*
    Validate each form field.
*/
if ($firstName == "") {
    $errors[] = "First name is required.";
}

if ($lastName == "") {
    $errors[] = "Last name is required.";
}

if ($age == "" || !is_numeric($age) || $age < 1 || $age > 120) {
    $errors[] = "Age must be a number between 1 and 120.";
}

if ($email == "" || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = "A valid email address is required.";
}

if ($phone == "") {
    $errors[] = "Phone number is required.";
}

if ($dob == "") {
    $errors[] = "Date of birth is required.";
}

if ($favoriteColor == "") {
    $errors[] = "Favorite color is required.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>James Form Response</title>
</head>
<body>

    <h1>Form Results</h1>

    <?php
    if (count($errors) > 0) {
    ?>
        <h2>Error: Please correct the following problem(s):</h2>
        <ul>
            <?php
            foreach ($errors as $error) {
            ?>
                <li><?php echo htmlspecialchars($error); ?></li>
            <?php
            }
            ?>
        </ul>

        <p><a href="JamesForm.html">Return to the form</a></p>

    <?php
    } else {
    ?>
        <h2>Information Submitted Successfully</h2>

        <table border="1" cellpadding="10">
            <tr>
                <th>Field</th>
                <th>Information Entered</th>
            </tr>
            <tr>
                <td>First Name</td>
                <td><?php echo htmlspecialchars($firstName); ?></td>
            </tr>
            <tr>
                <td>Last Name</td>
                <td><?php echo htmlspecialchars($lastName); ?></td>
            </tr>
            <tr>
                <td>Age</td>
                <td><?php echo htmlspecialchars($age); ?></td>
            </tr>
            <tr>
                <td>Email</td>
                <td><?php echo htmlspecialchars($email); ?></td>
            </tr>
            <tr>
                <td>Phone Number</td>
                <td><?php echo htmlspecialchars($phone); ?></td>
            </tr>
            <tr>
                <td>Date of Birth</td>
                <td><?php echo htmlspecialchars($dob); ?></td>
            </tr>
            <tr>
                <td>Favorite Color</td>
                <td>
                    <?php echo htmlspecialchars($favoriteColor); ?>
                    <span style="display:inline-block; width:20px; height:20px; background-color:<?php echo htmlspecialchars($favoriteColor); ?>;"></span>
                </td>
            </tr>
        </table>

        <p><a href="JamesForm.html">Submit another response</a></p>

    <?php
    }
    ?>

</body>
</html>