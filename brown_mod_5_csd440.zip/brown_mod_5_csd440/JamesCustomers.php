<?php
/*
    File Name: JamesCustomers.php
    Author: James
    Date: April 12, 2026
    Purpose:
    This PHP program creates and displays an array of customers.
    Each customer record includes a first name, last name, age,
    and phone number. The program also searches for customer
    records using different data fields and displays the results.
*/

/*
    Create an array of customers.
    Each customer is stored as an associative array.
*/
$customers = array(
    array("firstName" => "John", "lastName" => "Smith", "age" => 28, "phone" => "555-1001"),
    array("firstName" => "Maria", "lastName" => "Johnson", "age" => 34, "phone" => "555-1002"),
    array("firstName" => "David", "lastName" => "Brown", "age" => 22, "phone" => "555-1003"),
    array("firstName" => "Lisa", "lastName" => "Davis", "age" => 41, "phone" => "555-1004"),
    array("firstName" => "James", "lastName" => "Wilson", "age" => 30, "phone" => "555-1005"),
    array("firstName" => "Ashley", "lastName" => "Moore", "age" => 27, "phone" => "555-1006"),
    array("firstName" => "Michael", "lastName" => "Taylor", "age" => 36, "phone" => "555-1007"),
    array("firstName" => "Sarah", "lastName" => "Anderson", "age" => 19, "phone" => "555-1008"),
    array("firstName" => "Chris", "lastName" => "Thomas", "age" => 45, "phone" => "555-1009"),
    array("firstName" => "Emma", "lastName" => "Jackson", "age" => 31, "phone" => "555-1010")
);

/**
 * Displays customer records in an HTML table.
 *
 * @param array $customerList The list of customers to display
 * @param string $title The heading for the table
 */
function displayCustomers($customerList, $title)
{
?>
    <h2><?php echo htmlspecialchars($title); ?></h2>
    <table>
        <tr>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Age</th>
            <th>Phone Number</th>
        </tr>

        <?php
        foreach ($customerList as $customer) {
        ?>
            <tr>
                <td><?php echo htmlspecialchars($customer["firstName"]); ?></td>
                <td><?php echo htmlspecialchars($customer["lastName"]); ?></td>
                <td><?php echo htmlspecialchars($customer["age"]); ?></td>
                <td><?php echo htmlspecialchars($customer["phone"]); ?></td>
            </tr>
        <?php
        }
        ?>
    </table>
<?php
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>James Customers</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 30px;
            text-align: center;
        }

        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
        }

        th, td {
            border: 1px solid black;
            padding: 10px;
            text-align: center;
        }

        th {
            background-color: #f2f2f2;
        }

        h1, h2 {
            margin-top: 25px;
        }

        p {
            width: 80%;
            margin: 0 auto 20px auto;
        }
    </style>
</head>
<body>

    <h1>Customer Array Program</h1>
    
    <?php
    // Display all customer records
    displayCustomers($customers, "All Customers");

    /*
        Search Example 1:
        Find customers with the first name "James"
        using array_filter.
    */
    $firstNameSearch = array_filter($customers, function ($customer) {
        return $customer["firstName"] === "James";
    });
    displayCustomers($firstNameSearch, "Customers with First Name: James");

    /*
        Search Example 2:
        Find customers with age 30 or older
        using array_filter.
    */
    $ageSearch = array_filter($customers, function ($customer) {
        return $customer["age"] >= 30;
    });
    displayCustomers($ageSearch, "Customers Age 30 or Older");

    /*
        Search Example 3:
        Find customers whose last name starts with "J"
        using array_filter and strpos.
    */
    $lastNameSearch = array_filter($customers, function ($customer) {
        return strpos($customer["lastName"], "J") === 0;
    });
    displayCustomers($lastNameSearch, "Customers with Last Name Starting with J");

    /*
        Search Example 4:
        Find a customer by phone number.
    */
    $phoneSearch = array_filter($customers, function ($customer) {
        return $customer["phone"] === "555-1008";
    });
    displayCustomers($phoneSearch, "Customer with Phone Number: 555-1008");
    ?>

</body>
</html>