<?php
/*
    File Name: JamesTable3.php
*/

// Include the external file that contains the function
require_once 'tableFunction.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>James Table 3</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin-top: 30px;
        }

        table {
            margin: 0 auto;
            border-collapse: collapse;
        }

        th, td {
            border: 1px solid black;
            padding: 12px;
            width: 80px;
            height: 40px;
            text-align: center;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>

    <h1>Random Sum Table</h1>
    <p>Each cell shows the sum of two random numbers generated in PHP.</p>

    <table>
        <tr>
            <th>Col 1</th>
            <th>Col 2</th>
            <th>Col 3</th>
            <th>Col 4</th>
            <th>Col 5</th>
        </tr>

        <?php
        // Outer loop controls the rows
        for ($row = 1; $row <= 5; $row++) {
        ?>
            <tr>
                <?php
                // Inner loop controls the columns
                for ($col = 1; $col <= 5; $col++) {
                    $randomNum1 = rand(1, 50);
                    $randomNum2 = rand(1, 50);
                    $cellValue = getCellValue($randomNum1, $randomNum2);
                ?>
                    <td><?php echo $cellValue; ?></td>
                <?php
                }
                ?>
            </tr>
        <?php
        }
        ?>
    </table>

</body>
</html>