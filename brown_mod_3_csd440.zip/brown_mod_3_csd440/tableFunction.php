<?php
/*
    File Name: tableFunction.php
*/

function getCellValue($num1, $num2)
{
    return $num1 + $num2;
}
?>