<?php
/*
    File Name: JamesPDF.php
*/

require('fpdf.php');

$conn = new mysqli("localhost", "student1", "pass", "baseball_01");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

class PDF extends FPDF
{
    function Header()
    {
        $this->SetFont('Arial', 'B', 16);
        $this->Cell(0, 10, 'James Fitness Workouts Report', 0, 1, 'C');
        $this->Ln(5);
    }

    function Footer()
    {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 10);
        $this->Cell(0, 10, 'Page ' . $this->PageNo(), 0, 0, 'C');
    }
}

$sql = "SELECT workout_id, workout_name, workout_type, duration_minutes, calories_burned, workout_date
        FROM fitness_workouts";

$result = $conn->query($sql);

$pdf = new PDF();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 12);
$pdf->MultiCell(0, 8, 'This report displays fitness workout data.');
$pdf->Ln(8);

$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(15, 10, 'ID', 1);
$pdf->Cell(40, 10, 'Workout Name', 1);
$pdf->Cell(35, 10, 'Type', 1);
$pdf->Cell(30, 10, 'Duration', 1);
$pdf->Cell(35, 10, 'Calories', 1);
$pdf->Cell(35, 10, 'Date', 1);
$pdf->Ln();

$pdf->SetFont('Arial', '', 10);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $pdf->Cell(15, 10, $row["workout_id"], 1);
        $pdf->Cell(40, 10, $row["workout_name"], 1);
        $pdf->Cell(35, 10, $row["workout_type"], 1);
        $pdf->Cell(30, 10, $row["duration_minutes"] . ' min', 1);
        $pdf->Cell(35, 10, $row["calories_burned"], 1);
        $pdf->Cell(35, 10, $row["workout_date"], 1);
        $pdf->Ln();
    }
} else {
    $pdf->Cell(190, 10, 'No records found in the fitness_workouts table.', 1, 1, 'C');
}

$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(190, 10, 'End of Fitness Workouts Data Table', 1, 1, 'C');

$conn->close();

$pdf->Output('I', 'JamesFitnessWorkouts.pdf');
?>