<?php
/*
    File Name: JamesQueryTable.php
*/

$conn = new mysqli("localhost", "student1", "pass", "baseball_01");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT workout_id, workout_name, workout_type, duration_minutes, calories_burned, workout_date 
        FROM fitness_workouts";

$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>James Query Table</title>
</head>
<body>
    <h1>Fitness Workouts Table Results</h1>

    <?php if ($result && $result->num_rows > 0) { ?>
        <table border="1" cellpadding="10">
            <tr>
                <th>ID</th>
                <th>Workout Name</th>
                <th>Type</th>
                <th>Duration</th>
                <th>Calories Burned</th>
                <th>Date</th>
            </tr>

            <?php while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo htmlspecialchars($row["workout_id"]); ?></td>
                    <td><?php echo htmlspecialchars($row["workout_name"]); ?></td>
                    <td><?php echo htmlspecialchars($row["workout_type"]); ?></td>
                    <td><?php echo htmlspecialchars($row["duration_minutes"]); ?> minutes</td>
                    <td><?php echo htmlspecialchars($row["calories_burned"]); ?></td>
                    <td><?php echo htmlspecialchars($row["workout_date"]); ?></td>
                </tr>
            <?php } ?>
        </table>
    <?php } else { ?>
        <p>No records found or query failed.</p>
    <?php } ?>

</body>
</html>
<?php
$conn->close();
?>