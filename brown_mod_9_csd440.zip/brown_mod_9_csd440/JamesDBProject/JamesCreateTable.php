<?php
/*
    File Name: JamesCreateTable.php
*/

$conn = new mysqli("localhost", "student1", "pass", "baseball_01");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "CREATE TABLE fitness_workouts (
    workout_id INT AUTO_INCREMENT PRIMARY KEY,
    workout_name VARCHAR(50) NOT NULL,
    workout_type VARCHAR(50) NOT NULL,
    duration_minutes INT NOT NULL,
    calories_burned DECIMAL(6,2) NOT NULL,
    workout_date DATE NOT NULL
)";

$message = ($conn->query($sql) === TRUE)
    ? "Table fitness_workouts created successfully."
    : "Error creating table: " . $conn->error;

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>James Create Table</title>
</head>
<body>
    <h1>Create Fitness Workouts Table</h1>
    <p><?php echo htmlspecialchars($message); ?></p>
</body>
</html>