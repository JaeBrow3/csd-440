<?php
/*
    File Name: JamesAddForm.php
*/

$conn = new mysqli("localhost", "student1", "pass", "baseball_01");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $workoutName = trim($_POST["workout_name"]);
    $workoutType = trim($_POST["workout_type"]);
    $duration = trim($_POST["duration_minutes"]);
    $calories = trim($_POST["calories_burned"]);
    $date = trim($_POST["workout_date"]);

    if ($workoutName != "" && $workoutType != "" && is_numeric($duration) && is_numeric($calories) && $date != "") {
        $stmt = $conn->prepare("INSERT INTO fitness_workouts 
            (workout_name, workout_type, duration_minutes, calories_burned, workout_date)
            VALUES (?, ?, ?, ?, ?)");

        $stmt->bind_param("ssids", $workoutName, $workoutType, $duration, $calories, $date);

        if ($stmt->execute()) {
            $message = "Workout record added successfully.";
        } else {
            $message = "Error adding record: " . $conn->error;
        }
    } else {
        $message = "Please complete all fields correctly.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>James Add Workout</title>
</head>
<body>

    <h1>Add New Fitness Workout</h1>

    <?php if ($message != "") { ?>
        <p><strong><?php echo htmlspecialchars($message); ?></strong></p>
    <?php } ?>

    <form method="post" action="JamesAddForm.php">
        <p>
            <label>Workout Name:</label><br>
            <input type="text" name="workout_name" required>
        </p>

        <p>
            <label>Workout Type:</label><br>
            <input type="text" name="workout_type" required>
        </p>

        <p>
            <label>Duration in Minutes:</label><br>
            <input type="number" name="duration_minutes" required>
        </p>

        <p>
            <label>Calories Burned:</label><br>
            <input type="number" step="0.01" name="calories_burned" required>
        </p>

        <p>
            <label>Workout Date:</label><br>
            <input type="date" name="workout_date" required>
        </p>

        <p>
            <input type="submit" value="Add Workout">
            <input type="reset" value="Clear Form">
        </p>
    </form>

    <p><a href="JamesIndex.php">Return to Index</a></p>

</body>
</html>
<?php
$conn->close();
?>