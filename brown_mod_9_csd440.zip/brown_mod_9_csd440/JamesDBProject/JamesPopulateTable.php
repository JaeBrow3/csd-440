<?php
/*
    File Name: JamesPopulateTable.php
*/

$conn = new mysqli("localhost", "student1", "pass", "baseball_01");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO fitness_workouts 
(workout_name, workout_type, duration_minutes, calories_burned, workout_date)
VALUES
('Morning Run', 'Cardio', 30, 320.50, '2026-05-01'),
('Push Day', 'Strength', 45, 280.00, '2026-05-02'),
('Leg Workout', 'Strength', 60, 450.75, '2026-05-03'),
('Yoga Stretch', 'Flexibility', 25, 120.25, '2026-05-04'),
('Bike Ride', 'Cardio', 40, 390.00, '2026-05-05')";

$message = ($conn->query($sql) === TRUE)
    ? "Fitness workout records inserted successfully."
    : "Error inserting records: " . $conn->error;

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>James Populate Table</title>
</head>
<body>
    <h1>Populate Fitness Workouts Table</h1>
    <p><?php echo htmlspecialchars($message); ?></p>
</body>
</html>