<?php
/*
    File Name: JamesQuery.php
*/

$conn = new mysqli("localhost", "student1", "pass", "baseball_01");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$searchType = "";
$result = null;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $searchType = trim($_POST["workout_type"]);

    $stmt = $conn->prepare("SELECT * FROM fitness_workouts WHERE workout_type LIKE ?");
    $searchValue = "%" . $searchType . "%";
    $stmt->bind_param("s", $searchValue);
    $stmt->execute();
    $result = $stmt->get_result();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>James Query Workouts</title>
</head>
<body>

    <h1>Search Fitness Workouts</h1>

    <form method="post" action="JamesQuery.php">
        <label>Enter Workout Type:</label>
        <input type="text" name="workout_type" required>
        <input type="submit" value="Search">
    </form>

    <p><a href="JamesIndex.php">Return to Index</a></p>

    <?php if ($result !== null) { ?>
        <h2>Search Results for: <?php echo htmlspecialchars($searchType); ?></h2>

        <?php if ($result->num_rows > 0) { ?>
            <table border="1" cellpadding="10">
                <tr>
                    <th>ID</th>
                    <th>Workout Name</th>
                    <th>Workout Type</th>
                    <th>Duration</th>
                    <th>Calories Burned</th>
                    <th>Date</th>
                </tr>

                <?php while ($row = $result->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row["workout_id"]); ?></td>
                        <td><?php echo htmlspecialchars($row["workout_name"]); ?></td>
                        <td><?php echo htmlspecialchars($row["workout_type"]); ?></td>
                        <td><?php echo htmlspecialchars($row["duration_minutes"]); ?> minutes</td>
                        <td><?php echo htmlspecialchars($row["calories_burned"]); ?></td>
                        <td><?php echo htmlspecialchars($row["workout_date"]); ?></td>
                    </tr>
                <?php } ?>
            </table>
        <?php } else { ?>
            <p>No matching records found.</p>
        <?php } ?>
    <?php } ?>

</body>
</html>
<?php
$conn->close();
?>