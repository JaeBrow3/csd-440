<?php
/*
    File Name: JamesIndex.php
*/
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Fitness Database Index</title>
</head>
<body>

    <h1>Fitness Workout Database</h1>
    <p>Select a page below to manage or view the fitness workout database.</p>

    <h2>Module 9 Files</h2>
    <ul>
        <li><a href="JamesQuery.php">Search Workout Records</a></li>
        <li><a href="JamesAddForm.php">Add New Workout Record</a></li>
    </ul>

    <h2>Module 8 Files</h2>
    <ul>
        <li><a href="JamesCreateTable.php">Create Table</a></li>
        <li><a href="JamesPopulateTable.php">Populate Table</a></li>
        <li><a href="JamesQueryTable.php">View All Records</a></li>
        <li><a href="JamesDropTable.php">Drop Table</a></li>
    </ul>

</body>
</html>