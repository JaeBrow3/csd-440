<?php
/*
    File Name: JamesDropTable.php
*/

$conn = new mysqli("localhost", "student1", "pass", "baseball_01");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "DROP TABLE IF EXISTS fitness_workouts";

$message = ($conn->query($sql) === TRUE)
    ? "Table fitness_workouts dropped successfully."
    : "Error dropping table: " . $conn->error;

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>James Drop Table</title>
</head>
<body>
    <h1>Drop Fitness Workouts Table</h1>
    <p><?php echo htmlspecialchars($message); ?></p>
</body>
</html>