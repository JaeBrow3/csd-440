<?php
/**
*File Name: JamesTable2.php
*/
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>James Table 2</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin-top: 30px;
        }

        table {
            margin: 0 auto;
            border-collapse: collapse;
        }

        th, td {
            border: 1px solid black;
            padding: 12px;
            width: 60px;
            height: 40px;
            text-align: center;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>

    <h1>Random Number Table</h1>
    <p>This table was created using PHP nested loops.</p>

    <table>
        <tr>
            <th>Col 1</th>
            <th>Col 2</th>
            <th>Col 3</th>
            <th>Col 4</th>
            <th>Col 5</th>
        </tr>

        <?php
        // Outer loop controls the number of rows.
        for ($row = 1; $row <= 5; $row++) {
        ?>
            <tr>
                <?php
                // Inner loop controls the number of columns.
                for ($col = 1; $col <= 5; $col++) {
                    $randomNumber = rand(1, 100);
                ?>
                    <td><?php echo $randomNumber; ?></td>
                <?php
                }
                ?>
            </tr>
        <?php
        }
        ?>
    </table>

</body>
</html>