<?php
/*
    File Name: JamesPalindrome.php
*/

function isPalindrome($text)
{
    $cleanText = strtolower(str_replace(' ', '', $text));
    $reversedText = strrev($cleanText);

    return $cleanText === $reversedText;
}

function getReversedString($text)
{
    $cleanText = strtolower(str_replace(' ', '', $text));
    return strrev($cleanText);
}

// Array of six example strings
$examples = array(
    "level",
    "radar",
    "madam",
    "hello",
    "computer",
    "php code"
);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>James Palindrome</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 30px;
            text-align: center;
        }

        table {
            margin: 20px auto;
            border-collapse: collapse;
            width: 80%;
        }

        th, td {
            border: 1px solid black;
            padding: 10px;
            text-align: center;
        }

        th {
            background-color: #f2f2f2;
        }

        h1 {
            margin-bottom: 10px;
        }

        p {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>

    <h1>Palindrome Checker</h1>
    <p>This program tests six strings to determine whether each one is a palindrome.</p>

    <table>
        <tr>
            <th>Original String</th>
            <th>Reversed String</th>
            <th>Result</th>
        </tr>

        <?php
        // Loop through each example string and display the results
        foreach ($examples as $example) {
            $reversed = getReversedString($example);
            $result = isPalindrome($example) ? "Palindrome" : "Not a Palindrome";
        ?>
            <tr>
                <td><?php echo htmlspecialchars($example); ?></td>
                <td><?php echo htmlspecialchars($reversed); ?></td>
                <td><?php echo $result; ?></td>
            </tr>
        <?php
        }
        ?>
    </table>

</body>
</html>