<?php
/*
    File Name: JamesJSON.php
*/

$errors = array();
$jsonOutput = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $userData = array(
        "first_name" => trim($_POST["first_name"] ?? ""),
        "favorite_movie" => trim($_POST["favorite_movie"] ?? ""),
        "favorite_color" => trim($_POST["favorite_color"] ?? ""),
        "favorite_food" => trim($_POST["favorite_food"] ?? ""),
        "favorite_sport" => trim($_POST["favorite_sport"] ?? ""),
        "favorite_music" => trim($_POST["favorite_music"] ?? ""),
        "dream_vacation" => trim($_POST["dream_vacation"] ?? ""),
        "favorite_animal" => trim($_POST["favorite_animal"] ?? "")
    );

    // Validate all fields
    foreach ($userData as $field => $value) {
        if ($value == "") {
            $errors[] = ucfirst(str_replace("_", " ", $field)) . " is required.";
        }
    }

    // Convert to JSON if no errors
    if (count($errors) == 0) {
        $jsonOutput = json_encode($userData, JSON_PRETTY_PRINT);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>James JSON Form</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 30px;
        }

        h1, h2 {
            text-align: center;
        }

        form, .output, .error {
            width: 60%;
            margin: 20px auto;
            padding: 20px;
            background-color: white;
            border: 1px solid #cccccc;
        }

        label {
            font-weight: bold;
        }

        input[type="text"] {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            margin-bottom: 15px;
        }

        input[type="submit"],
        input[type="reset"] {
            padding: 10px 15px;
        }

        pre {
            background-color: #eeeeee;
            padding: 15px;
            border: 1px solid #999999;
        }

        .error {
            color: darkred;
        }
    </style>
</head>

<body>

    <h1>JSON Data Form</h1>

    <form method="post" action="JamesJSON.php">

        <label>First Name:</label>
        <input type="text" name="first_name">

        <label>Favorite Movie:</label>
        <input type="text" name="favorite_movie">

        <label>Favorite Color:</label>
        <input type="text" name="favorite_color">

        <label>Favorite Food:</label>
        <input type="text" name="favorite_food">

        <label>Favorite Sport:</label>
        <input type="text" name="favorite_sport">

        <label>Favorite Music Genre:</label>
        <input type="text" name="favorite_music">

        <label>Dream Vacation:</label>
        <input type="text" name="dream_vacation">

        <label>Favorite Animal:</label>
        <input type="text" name="favorite_animal">

        <br>

        <input type="submit" value="Submit">
        <input type="reset" value="Clear Form">

    </form>

    <?php if ($_SERVER["REQUEST_METHOD"] == "POST" && count($errors) > 0) { ?>

        <div class="error">

            <h2>Error Display</h2>

            <p>Please correct the following errors:</p>

            <ul>
                <?php
                foreach ($errors as $error) {
                    echo "<li>" . htmlspecialchars($error) . "</li>";
                }
                ?>
            </ul>

        </div>

    <?php } ?>

    <?php if ($jsonOutput != "") { ?>

        <div class="output">

            <h2>JSON Output</h2>

            <pre><?php echo htmlspecialchars($jsonOutput); ?></pre>

        </div>

    <?php } ?>

</body>
</html>